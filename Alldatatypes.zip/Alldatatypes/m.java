class Marks 
{
  public static void main(String a[])
{
   byte marks=99;
   System.out.print(marks);
}
}
 