class LifeCycle
{
  public static void main(String a[])
  {
     int AGE=12;
     int age=17;
     int Age= 20;
     int aGe = 21;
     int agE = 22;
     int AGe = 23;
     int aGE = 24;
     System.out.println(AGE);
     System.out.println(age);
     System.out.println(Age);
}
}

       