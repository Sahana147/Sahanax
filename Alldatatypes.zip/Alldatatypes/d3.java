class Apple
{
  public static void main(String a[])
{
   char c =  A;
   System.out.print(c);
}
}

