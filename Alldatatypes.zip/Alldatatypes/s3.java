class flat 
{
  public static void main(String a[])
{
  short flat = 32767;
  System.out.print(flat);
}
}

