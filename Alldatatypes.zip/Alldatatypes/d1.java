class speed 
{
   public static void main(String a[])
{
   double s= 9.0000004d;
   System.out.print(s);
}
}

 

