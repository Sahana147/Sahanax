class weight
{
  public static void main(String a[])
{
   double d = 2.000152;
   System.out.print(d);
}
}

