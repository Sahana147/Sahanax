class countable
{
  public static void main(String a[])
{
  short count = 500;
  System.out.print(count);
}
}
 
