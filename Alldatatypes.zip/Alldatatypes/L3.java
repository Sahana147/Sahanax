class hairs
{
  public static void main(String a[])
{
  long s=879654123654789654L;
  System.out.print(s);
}
}

 

