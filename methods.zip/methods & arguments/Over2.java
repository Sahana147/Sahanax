class AddingNumber
{
	public static void main( String a[])
	{
	  int output = add();
	  System.out.println(output);
      double ans = add(12.51 , 8.02);
      System.out.println(ans);
	  double answer = add(12.51, 8.02, 2.45 );
      System.out.println(answer);
	  
	}
	
	static int add()
	{
		int a=20;
		int b=55;
		int c = a + b;
		return c;
		
	}
	
	static double add( double subOne, double subTwo)
	{
		double finalMarks = (subOne + subTwo);
		return finalMarks;
	}
	
		static double add( double subOne, double subTwo , double subThree )
	{
		double finalMarks = (subOne + subTwo + subThree) ;
		return finalMarks;
	}
}

	
	
