class PrintName
{
public static void main(String a[])
{
	  String name = printName("sahana");
	  System.out.println(name);
}
	
     
	 static  String printName(String name)
	 {
	   for (int i=0; i<=15;i++)
	   {
	   System.out.println(name);
	   }
     

     return "null";
	}
}
	 
	 
	