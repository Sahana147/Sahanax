class FruitsStall
{
  String fruitName = "Mango";
  float fruitPrice = 100.00;
  int noOfFruits   =  5;
  
  