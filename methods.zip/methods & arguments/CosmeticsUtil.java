class CosmeticsUtil
{
  public static void main(String a[])
  {
    Cosmetics makeup = new Cosmetics();
	System.out.println(makeup.name);
	System.out.println(makeup.color);
	System.out.println(makeup.price);
	
	makeup.graceLook();
	makeup.averageLook();
  }
}

	