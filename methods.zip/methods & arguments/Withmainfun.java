class TubeLightColors 
{
	public static void main(String a[])
	{
		TubeLight.giveLight();    //Accessing using class name which is not present in main class
		TubeLight.giveLight("rainbow colors");
	}
}

	