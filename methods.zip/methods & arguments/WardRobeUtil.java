class WardRobeUtil
{
  public static void main(String a[])
  {
    WardRobe locker = new WardRobe();
	locker.design = "customized";
	System.out.println(locker.design);
	System.out.println(locker.noOfRacks);
	
	locker.makeThingsEasy();
	locker.ruined();
  }
}
	
	