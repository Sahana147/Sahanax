class WardRobe
{
   String design = "westren";
   int noOfRacks = 14;
   
   void makeThingsEasy()
   {
     System.out.println("things get easily available");
   }
   
   void ruined()
   {
   System.out.println("things get worse and defeat our time");
   }
     
}
