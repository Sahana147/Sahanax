class FindGreatestNumber
{
	public static void main( String a[])
	{
		int value = maxOfTwoNumber(180,270);
		System.out.println(value);
		
	}
	
 
  static int maxOfTwoNumber(int firstNumber, int secondNumber)
   {
	   if(firstNumber>secondNumber)
	    //System.out.println("firstNumber");
	   return firstNumber;
	   else
	  // System.out.println("secondNumber");
	   return secondNumber;
	   
	   return 0;
   }
}
 
	   `