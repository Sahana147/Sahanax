class EvenOrOdd
{
 public static void main(String a[])
  {
      int num = isEven(66);//method calling or caller
	  System.out.println(num + " is even");
	  int numb = isEven(1287);
	  System.out.println(numb + " is odd");
	  
 }
 
           static int isEven(int number) // called method and this method is paramaterised
			{
			if(number%2!= 0)
			return number;
			else
			return number;
			}

}



