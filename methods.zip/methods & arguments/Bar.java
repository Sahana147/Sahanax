class Bar
{
   String name = "Taquila" ;
   String address = "MG Road";
   int noOfBrands = 125;
     
	 void makePeopleHappy()
	 {
	 System.out.println("Hanging over there");
	 }
	 
	  void makeLifeWorse()
	  {
		System.out.println("when you get addicted"); 
	  }		
		  
 }
 