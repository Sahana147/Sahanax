class FruitsStall
{
  String adress = "shantisagar";
  float  rent = 40.0002f ;
  int noOfDifferentFruits = 10;
  
      void mango()
	  {
	  System.out.println("like unriped mangoes");
	  }
	  void banana()
	  {
      System.out.println("want to eat daily");
	  }
}
	  
  
  