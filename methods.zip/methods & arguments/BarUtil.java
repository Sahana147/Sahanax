class BarUtil
{
   public static void main(String a[])
   {
	   
        Bar bar = new Bar(); //structure of creating a object
		 bar.makePeopleHappy();
		//bar.name = "Navarang bar";
		//bar.address = "Rajkumar Road";
		bar.noOfBrands = 90;
		System.out.println(bar.name);
		System.out.println(bar.address);
		System.out.println(bar.noOfBrands);
		
		//bar.makePeopleHappy();
		//bar.makeLifeWorse();
		
		
		
   }
}
 