class PhonePay
{
 public static void main(String a[])
 {
        String amount = phonePay(797,9874,21548);
		System.out.println(amount);
		
 }
 
    static String phonePay(long amount1,long amount2,long amount3 )
	 {
	   for(long k=0; k<6; k++)
	   {
	      System.out.println(amount1);
		  System.out.println(amount2);
		  System.out.println(amount3);
	   }
	   return "void";
	 }
}

	   
	   
	   