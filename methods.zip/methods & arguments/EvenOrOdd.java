class EvenOrOdd
{
 public static void main(String a[])
  {
      isEven(587);//method calling or caller
	  isEven(1287);
	  isEven(58);
	  isEven(4);
 }
 
           static void isEven(int number) // called method and this method is paramaterised
			{
			if(number%2!= 0)
			System.out.println(number + " is odd");
			else
			System.out.println(number + " is even");

			}

}





