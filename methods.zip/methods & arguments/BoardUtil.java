class BoardUtil
{
public static void main(String a[])
{
 Board board = new Board();
 
 board.toWrite();
 board.toWrite("cello");
 
 }
}

 
 


