class CompetitiveExam
{
  String examName = "Upsc";
  float noOfAspirants = 567.8f;
  
  String firstAttempt()
  {
    //System.out.println("Awful experience at firstAttempt & less chances of clearing");
	return "one";
  }
  
  int firstAttempt( int result)
   {
       System.out.println("chances of clearing is more");
	  return result;
	 
   }
   
   
   
 }
 

     
  
  