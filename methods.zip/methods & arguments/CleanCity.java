class CleanCity
{
  public static void main(String a[])
  {
	  String place = cleanCity("mysore");
	  //System.out.println(place);
      // cleanCity("mysore");
	  
   
  }
     
	     static String cleanCity(String place)
		  {
			 //return place;
		     System.out.println(place);
			 return place;
		  }
}

		   
		 
		  

