class Cosmeticss
{
  String name; 
  int price;
  static  String brand;
  //Cosmeticss.price = 4585;
   
  
  void graceLook()
  {
    System.out.println("it gives makeup look even you wear only lipstick");
  }
   
   public static void main(String a[])
   {
	   
	  Cosmeticss.brand = "Maybeline";
	  Cosmeticss cos = new  Cosmeticss();
      cos.name = "lipstick";
	  cos.price=34;
	  //cos.brand = "L18"; //its dublicating values everytime no need of calling this everytime bcz its in a static 
      System.out.println(cos.name + " " + cos.price + " " + cos.brand );
	  
	  
	  Cosmeticss cosTwo = new  Cosmeticss();
      cos.name = "nailPoilsh";
      cos.price=10;
      System.out.println(cos.name + " " + cos.price + " "+ cos.brand);


	  
	  Cosmeticss cosOne = new  Cosmeticss();
      cos.name = "eyeliner";
	  cos.price=700;
      System.out.println(cos.name + " " + cos.price + " "+ cos.brand );
      cos.graceLook();
   }
		
}