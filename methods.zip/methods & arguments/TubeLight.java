class TubeLight
{
	
	static void giveLight()
	{
	System.out.println("pink light");
	}
	
	static void giveLight(String bulb)
	{
	System.out.println("rainbow colors");
	}
	
}
