class Pooja
{
  public static void main(String a[])
  {
    String day = pooja();
	System.out.println(day);
    
	
  }
  
  static String pooja()
  {
	  return "fun";
  }
}

  
  