class Sarees
{
  String style = "mysore silk";
  String color = "dark green";
  float price =  0.0f;
 
  void everGreen()
  {
  System.out.println("All time favourite for all girls & aunties");
  }
  void costly()
  {
   System.out.println("only thing is it's not offeredable for everyone");
  }
 
}
    