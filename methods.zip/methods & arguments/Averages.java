class Averages
{
 public static void main(String a[])

{


}

  static double avg(double firstSubject, double secondSubject , double thirdSubject)
	   {
	      double total = (firstSubject + secondSubject + thirdSubject)/3;
		  return total;
	   }
}