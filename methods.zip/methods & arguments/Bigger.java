class FindGreatestOfTwoNum
{
  public static void main(String a[])
 {
      maxOfTwoNum(99,54); 
	  maxOfTwoNum(45,4);
	  maxOfTwoNum(100,0);
	 //int num = maxOfTwoNum(5,4);
	  // System.out.println(num);
	
 }
              static void maxOfTwoNum(int numOne, int numTwo)
			  {
			    if(numOne>numTwo)
				{
				//return numOne;
				System.out.println(numOne);
				}
				else
				{
			     //return numTwo greater");
				 System.out.println(numTwo);
				}
			     
			  }
}
			  
    