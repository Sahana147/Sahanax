class SareesUtil
{
 public static void main(String a[])
 {
	 
 
   Sarees saree = new Sarees();
   saree.everGreen();
   saree.costly();
   saree.price=55555555555578.99888888888888888f;
   System.out.println(saree.style);
   System.out.println(saree.color);
   System.out.println(saree.price);
 }
}

   