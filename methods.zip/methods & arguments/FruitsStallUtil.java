class FruitsStallUtil
{
 public static void main(String a[])
 {
	 FruitsStall fruits = new  FruitsStall();
	 
     fruits.rent = 10.11201284f ;
	 fruits.mango();
	 fruits.banana();
	 System.out.println(fruits.adress);
	 System.out.println(fruits.rent);
	 System.out.println(fruits.noOfDifferentFruits );
 }
}




 

	
	 
	 
   