class CompetitiveExamUtil
{
  public static void main(String a[])
  {
  CompetitiveExam exam = new CompetitiveExam();
  //exam.noOfAspirants= 123456974515484 ;
  
  
  System.out.println(exam.examName);
  
  System.out.println(exam.noOfAspirants);
  
  
  String resultOne = exam.firstAttempt();
  System.out.println(resultOne);
  
  int resultTwo = exam.firstAttempt(1);
  System.out.println(resultTwo);
  }
}


  
  
  
   
   