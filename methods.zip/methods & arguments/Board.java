class Board
{
  
  void toWrite()

 {
   System.out.println("writing on  the board");
 }
 void toWrite(String pen)//method overloading : same method name but differnt parameters
 {
    System.out.println("writing on board with marker");
 }
}

    