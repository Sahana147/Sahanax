class Cosmetics
{
  String name = "lipstick";
  String color = "matte red";
  int price = 499;
  
  void graceLook()
  {
    System.out.println("it gives makeup look even you wear only lipstick");
  }
   
   void averageLook()
   {
    System.out.println("if you  don't wear it"); 
   }
}

  
  
   
    