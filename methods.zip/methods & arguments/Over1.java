class Board
{
  public static void main(String a[])
  {
   toWrite();  
   toWrite("Marker"); 
  }
 

  static void toWrite()

 {
   System.out.println("writing on  the board");
 }
 
  static void toWrite(String pen)//method overloading : same method name but differnt parameters
 {
    System.out.println("writing on board with marker");
 }
}

    