class FindFactorial
{
  public static void main(String a[])
  {
    int f = myFact(3);
   	 int g = myFact(3);
	 int r = myFact(3);
	   int finalOutput = f/(g*r);
	 System.out.println(finalOutput);
	 double total = Averages.avg(45.236,65.021,25.00);
	 System.out.println(total);
  }
         static int myFact( double n)
		 {
          int fact=1;
		  for( int i=1; i<=n ; i++)
		  {
		  fact = fact * i;
		  }
		   return fact;
		  
         }
}

		  