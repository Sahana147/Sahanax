class CleanCity
{
  public static void main(String a[])
{
  String visited[] = {"mysore", "banglore", "hubbali", "udupi"};
  for (int i=0; i<=3; i++)
  System.out.pirnt(visited[i]);
}
}


 
