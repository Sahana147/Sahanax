class Places
{
  public static void main(String a[])
{
  String places[] = {"mysore","banglore","chikkamanglore","udupi"};
  System.out.println(places[0]);
  System.out.println(places[1]);
  System.out.println(places[2]);
  System.out.println(places[3]);
}
}
