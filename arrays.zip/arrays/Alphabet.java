class Alphabets
{
  public static void main(String a[])
{
  char words[] = {'g', 'd', 'e', 'v', 'r'};
  for (int  i=0; i<6; i++)
  System.out.println(words[i]);
}
}

 