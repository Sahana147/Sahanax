 class Routes
 {
   public static void main(String a[])
{
   int busRoute[] = { 69,81,114,11,201 };
   for(int j=0; j<6; j++)
   System.out.println(busRoute[j]);
}
}
 






