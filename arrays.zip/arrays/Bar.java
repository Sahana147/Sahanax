class Bar
{
  public static void main(String a[])
{
   String bar[] = {"scotch","brandy","30","90"};
   for(int i=0; i<=3; i++)
   System.out.printlntt+(bar[i]);

    
}
}
 