class TextBook
{
   public static void main(String a[])
{
   byte books=127;
   System.out.print(books);
}
}
