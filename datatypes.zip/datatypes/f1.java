class Age
{
   public static void main(String a[])
{
   float priya = 27.5f;
   System.out.print(priya);
}
}

 

