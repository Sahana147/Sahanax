class Me
{
  public static void main(String a[])
{
   char c = 'H';
   System.out.print(c);
}
}

