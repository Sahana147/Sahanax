class initial
{
  public static void main(String a[])
{
   char c = 'K';
   System.out.print(c);
}
}

