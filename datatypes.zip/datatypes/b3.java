class Temperature
{
   public static void main(String a[])
{
   byte temp = -128;
   System.out.print(temp);
}
}
