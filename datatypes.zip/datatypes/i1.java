class prime
{
  public static void main(String a[])
{
  int i=2;
  System.out.print(i);
}
}
