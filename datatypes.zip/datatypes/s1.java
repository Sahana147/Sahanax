class Chairs
{
  public static void main(String a[])
{
  short chairs=32000;
  System.out.print(chairs);
}
}
