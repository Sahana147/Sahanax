class speed 
{
   public static void main(String a[])
{
   float s= 9.00004f;
   System.out.print(s);
}
}

 

