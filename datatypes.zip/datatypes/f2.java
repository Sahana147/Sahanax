class time 
{
   public static void main(String a[])
{
   float t= 12.45f;
   System.out.print(t);
}
}

 

