class Apple
{
  public static void main(String a[])
{
   char c = 'a';
   System.out.print(c);
}
}

