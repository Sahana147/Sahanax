public class Sweet
{ 
     String name;
     String color;
     double price;
}