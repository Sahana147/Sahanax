class Planet
{ 
   static  String country = "India";
   static  String state = " karnataka";
   public static void main(String a[])
{
 
   System.out.println(country "+\n");
   System.out.println(state);
}
}

   
   