class SweetTester
{
    public static void main(String a[])
     {
           Sweet sweet = new Sweet(); 
             sweet.name="gulabJaamun";
             sweet.color="brown";
     }
}














class SweetTester
{
    public static void main(String a[])
     {
           Sweet sweetCorner = new Sweet(); 
             sweetCorner.name="gulabJaamun";
             sweetCorner.color="brown";
     System.out.println(sweetCorner.name);
System.out.println( sweetCorner.color);
     }
}




























