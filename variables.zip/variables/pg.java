class Pg
{ 
  
   Static String name ="veenabhaskar";
   Static int rooms = 30;
  public static void main(String a[])
{
   
   System.out.println(name);
   System.out.println(rooms);

}
}

   